BACKUP_DIRECTORY="/var/backups/filesContromisure"

backup_configurazione(){
    echo "<-- Creazione dei file di backup delle configurazioni in corso -->"
    mkdir -p $BACKUP_DIRECTORY
    sudo cp /etc/samba/smb.conf $BACKUP_DIRECTORY/smb.conf.bak #File di configurazione modifcato per i 2 exploit samba
    sudo cp /etc/apache2/sites-available/default $BACKUP_DIRECTORY/default.bak #File di configurazione modificato per "php_cgi_arg_injection"
    sudo cp /usr/share/tomcat5.5/conf/web.xml $BACKUP_DIRECTORY/web.xml.bak #File di configurazione modificato per "tomcat"
    sudo cp /etc/postgresql/8.3/main/pg_hba.conf $BACKUP_DIRECTORY/pg_hba.conf.bak #File di configurazione modificato per "postgres_payload"
}

disabilita_wide_links(){
    echo "<-- Disattivazione dell'opzione 'wide links' (samba) -->"
    #sudo sed -i 's/^\s*wide links\s*=.*/wide links = no/' /etc/samba/smb.conf
    sudo sed -i '/#### Debugging\/Accounting ####/i\wide links = no' /etc/samba/smb.conf
    sudo /etc/init.d/samba restart
}

disabilita_username_map_script(){
    echo "<-- Disattivazione dell'opzione 'username map script' (samba) -->"
    sudo sed -i 's/^\s*username map script\s*=.*/# username map script =/' /etc/samba/smb.conf
    sudo /etc/init.d/samba restart
}

applica_regole_firewall_vsftpd_backdoor(){
    echo "<-- Applicazione delle regole di firewall per controllare il payload dei pacchetti (vsftpd) -->"
    sudo iptables -A INPUT -p tcp --dport 21 -m string --string ":)" --algo bm -j DROP
}

applica_regole_firewall_distcc_exec(){
    echo "<-- Applicazione delle regole di firewall per limitare l'accesso a host fidati (distcc) -->"
    sudo iptables -A INPUT -p tcp --dport 3632 -s 192.168.1.1 -j DROP
}

modifica_conf_php_cgi(){
    echo "<-- Modifica della configurazione di apache per limitare la possibilità di usare opzioni nell'url (php_cgi_arg_injection) -->"
    sudo sed -i '/<\/Directory>/a <IfModule mod_rewrite.c>\n    RewriteEngine On\n  RewriteCond %{QUERY_STRING} (\;|\||\`|\$|\&|\>|\<|\(|\)|\{|\\|\[|\]|\~|\^|\%|\@|\#) [NC,OR]\n   RewriteCond %{QUERY_STRING} \.\.\/ [OR]\n   RewriteCond %{QUERY_STRING} \\? [NC]\n   RewriteRule ^.*$ - [F,L]\n  </IfModule>' /etc/apache2/sites-available/default
    sudo /etc/init.d/apache2 restart
}

modifica_conf_tomcat(){
    echo "<-- Modifica della configurazione di tomcat per limitare l'accesso a host fidati (tomcat_mgr_upload) -->"
    sudo sed -i '/<\/servlet>/a <Valve className="org.apache.catalina.valves.RemoteAddrValve" allow="192\.168\.175\.\d+|127\.\d+\.\d+\.\d+\/> </Context>' /usr/share/tomcat5.5/conf/web.xml
    sudo /etc/init.d/tomcat5.5 restart
}

modifica_accesso_a_postgres(){
    echo "<-- Limitazione dell'accesso all'account postgres (postgres_payload) -->"
    sudo sed -i '/^# IPv4 local connections:/a host all postgres 192.168.174.131 md5' /etc/postgresql/8.3/main/pg_hba.conf
    sudo /etc/init.d/postgresql-8.3 restart
}

ripristino_backup(){
    echo "<-- Ripristino delle configurazioni originali -->"

    if [ -f $BACKUP_DIRECTORY/smb.conf.bak ]; then
        sudo cp $BACKUP_DIRECTORY/smb.conf.bak /etc/samba/smb.conf
        echo "<-- File di configurazione di samba ripristinato -->"
    else
        echo "<-- Backup del file di configurazione di samba non trovato -->"
    fi

    if [ -f $BACKUP_DIRECTORY/default.bak ]; then
        sudo cp $BACKUP_DIRECTORY/default.bak /etc/apache2/sites-available/default
        echo "<-- File di configurazione di apache ripristinato -->"
    else
        echo "<-- Backup del file di configurazione di apache non trovato -->"
    fi

    if [ -f $BACKUP_DIRECTORY/web.xml.bak ]; then
        sudo cp $BACKUP_DIRECTORY/web.xml.bak /usr/share/tomcat5.5/conf/web.xml
        echo "<-- File di configurazione di tomcat ripristinato -->"
    else
        echo "<-- Backup del file di configurazione di apache non trovato -->"
    fi

    if [ -f $BACKUP_DIRECTORY/pg_hba.conf.bak ]; then
        sudo cp $BACKUP_DIRECTORY/pg_hba.conf.bak /etc/postgresql/8.3/main/pg_hba.conf
        echo "<-- File di configurazione di postgres ripristinato -->"
    else
        echo "<-- Backup del file di configurazione di postgres non trovato -->"
    fi

    echo "<-- Ripristino delle regole di firewall -->"
    sudo iptables -D INPUT -p tcp --dport 21 -m string --string ":)" --algo bm -j DROP
    sudo iptables -D INPUT -p tcp --dport 3632 -s 192.168.1.1 -j DROP
    echo "<-- Regole di firewall ripristinate -->"

    echo "<-- Riavvio di tutti i servizi -->"
    sudo /etc/init.d/samba restart
    sudo /etc/init.d/apache2 restart
    sudo /etc/init.d/tomcat5.5 restart
    sudo /etc/init.d/postgresql-8.3 restart

    echo "<-- Rispristino completato -->"
}

echo "Scegli un'operazione da eseguire:"
echo "1) Backup delle configurazioni originali"
echo "2) Disattivazione dell'opzione 'wide links' (samba)"
echo "3) Disattivazione dell'opzione 'username map script' (samba)"
echo "4) Applicazione delle regole di firewall per controllare il payload dei pacchetti (vsftpd)"
echo "5) Applicazione delle regole di firewall per limitare l'accesso a host fidati (distcc)"
echo "6) Modifica della configurazione di apache per limitare la possibilità di usare opzioni nell'url (php_cgi_arg_injection)"
echo "7) Modifica della configurazione di tomcat per limitare l'accesso a host fidati (tomcat_mgr_upload)"
echo "8) Limitazione dell'accesso all'account postgres (postgres_payload)"
echo "9) Ripristino delle configurazioni di default"
read -p "Inserisci il numero dell'operazione che vuoi eseguire: " operazione

case $operazione in
    1) backup_configurazione ;;
    2) disabilita_wide_links ;;
    3) disabilita_username_map_script ;;
    4) applica_regole_firewall_vsftpd_backdoor ;;
    5) applica_regole_firewall_distcc_exec ;;
    6) modifica_conf_php_cgi ;;
    7) modifica_conf_tomcat ;;
    8) modifica_accesso_a_postgres ;;
    9) ripristino_backup ;;
    *) echo "Scelta non valida" ;;
esac



